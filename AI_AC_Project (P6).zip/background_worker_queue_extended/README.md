Background Worker + Queue — Extended Project

This extended version includes robust logging, validation, and improved task handling.

Quickstart (Windows):
1. Ensure Redis is running (Docker recommended):
   docker run -d -p 6379:6379 redis

2. Create virtualenv and install requirements:
   python -m venv venv
   venv\Scripts\activate
   pip install -r requirements.txt

3. Start the Flask API in one terminal:
   python app.py

4. Start the worker in another terminal:
   python worker.py

5. Enqueue a job with curl or Postman:
   curl -F "image=@test.jpg" -F "width=400" -F "height=300" http://localhost:5000/resize

Notes:
- Output files are saved to the images/ directory with suffix _resized.
- Job progress is available via GET /status/<job_id> which returns job.meta.progress
- Transient I/O errors trigger retries; file-not-found errors do not.
