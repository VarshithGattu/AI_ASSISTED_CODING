"""Flask API that enqueues image resize jobs to RQ/Redis."""
import os
from flask import Flask, request, jsonify, send_from_directory, abort
from redis import Redis
from rq import Queue
from datetime import datetime
from pathlib import Path
import uuid
import logging

from config import IMAGES_DIR, REDIS_URL, QUEUE_NAME, LOG_FILE
from utils import setup_logging, secure_filename, human_readable_size
from tasks import TransientError

# configure logging first
setup_logging(log_file=LOG_FILE)
logger = logging.getLogger(__name__)

app = Flask(__name__)
redis_conn = Redis.from_url(REDIS_URL)
q = Queue(name=QUEUE_NAME, connection=redis_conn)

MAX_UPLOAD_SIZE = 10 * 1024 * 1024  # 10 MB

def validate_dimensions(value):
    try:
        v = int(value)
        if v <= 0 or v > 10000:
            raise ValueError('dimension out of range')
        return v
    except Exception:
        raise ValueError('invalid dimension')

@app.route('/resize', methods=['POST'])
def enqueue_resize():
    if 'image' not in request.files:
        return jsonify({'error':'no image part named "image" included in form-data'}), 400
    file = request.files['image']
    filename = secure_filename(file.filename)
    if filename == '':
        return jsonify({'error':'invalid filename'}), 400

    # optional validation of size
    file.seek(0, os.SEEK_END)
    size = file.tell()
    file.seek(0)
    if size == 0:
        return jsonify({'error':'empty file uploaded'}), 400
    if size > MAX_UPLOAD_SIZE:
        return jsonify({'error':'file too large', 'max_bytes': MAX_UPLOAD_SIZE}), 413

    # dimensions
    try:
        width = validate_dimensions(request.form.get('width', 800))
        height = validate_dimensions(request.form.get('height', 600))
    except ValueError as e:
        return jsonify({'error': str(e)}), 400

    # save file
    unique_name = f"{datetime.utcnow().strftime('%Y%m%d%H%M%S')}_{uuid.uuid4().hex}_{filename}"
    input_path = IMAGES_DIR / unique_name
    file.save(str(input_path))
    logger.info('Saved upload %s (%s)', unique_name, human_readable_size(input_path.stat().st_size))

    # enqueue job with retry strategy: 3 retries for TransientError only
    from rq import Retry
    job = q.enqueue('tasks.resize_image', args=(str(input_path), width, height), retry=Retry(max=3, interval=[10, 30, 60]), result_ttl=3600)
    logger.info('Enqueued job %s for file %s', job.id, unique_name)
    return jsonify({'message':'enqueued', 'job_id': job.get_id()}), 202

@app.route('/status/<job_id>', methods=['GET'])
def status(job_id):
    from rq.job import Job
    try:
        job = Job.fetch(job_id, connection=redis_conn)
    except Exception:
        return jsonify({'error':'job not found'}), 404
    meta = getattr(job, 'meta', {})
    return jsonify({'id': job.id, 'status': job.get_status(), 'result': job.result, 'meta': meta})

@app.route('/images/<filename>', methods=['GET'])
def serve_image(filename):
    path = IMAGES_DIR / filename
    if not path.exists():
        abort(404)
    return send_from_directory(str(IMAGES_DIR), filename, as_attachment=False)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=int(os.getenv('PORT', 5000)))
