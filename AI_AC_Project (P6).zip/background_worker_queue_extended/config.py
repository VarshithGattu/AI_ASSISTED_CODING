import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
IMAGES_DIR = BASE_DIR / 'images'
IMAGES_DIR.mkdir(parents=True, exist_ok=True)

# Redis connection settings (can be overridden by env vars)
REDIS_HOST = os.getenv('REDIS_HOST', 'localhost')
REDIS_PORT = int(os.getenv('REDIS_PORT', 6379))
REDIS_URL = os.getenv('REDIS_URL', f'redis://{REDIS_HOST}:{REDIS_PORT}')

# RQ queue name
QUEUE_NAME = os.getenv('QUEUE_NAME', 'image-tasks')

# Logging
LOG_FILE = BASE_DIR / 'worker_api.log'
