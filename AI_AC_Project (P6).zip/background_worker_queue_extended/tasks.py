"""Task implementations for image resizing. These functions are executed by RQ workers."""
from PIL import Image, ImageOps
from pathlib import Path
import logging
import time
from rq import get_current_job

logger = logging.getLogger(__name__)

SUPPORTED_FORMATS = ('JPEG', 'PNG', 'WEBP', 'BMP')

class TransientError(Exception):
    """Indicate a transient error that should be retried."""
    pass

def resize_image(filepath: str, width: int, height: int, keep_aspect: bool=True, quality: int=85):
    """Resize an image and save output alongside the original with suffix `_resized`.

    The job updates `job.meta` with progress percentages to allow status polling.
    Raises TransientError for recoverable issues (e.g., temporary I/O issue).
    """
    job = get_current_job()
    try:
        p = Path(filepath)
        if not p.exists():
            raise FileNotFoundError(f"Input file not found: {filepath}")
        # progress 0%
        if job:
            job.meta['progress'] = 0
            job.save_meta()

        logger.info('Opening image: %s', filepath)
        start = time.time()
        with Image.open(str(p)) as img:
            img = img.convert('RGB')
            orig_size = img.size
            logger.debug('Original size: %s', orig_size)
            if keep_aspect:
                img.thumbnail((int(width), int(height)), Image.LANCZOS)
            else:
                img = ImageOps.fit(img, (int(width), int(height)), Image.LANCZOS)

            # progress 60%
            if job:
                job.meta['progress'] = 60
                job.save_meta()

            out_name = p.with_name(p.stem + '_resized' + p.suffix)
            img.save(str(out_name), optimize=True, quality=int(quality))
            duration = time.time() - start
            logger.info('Saved resized image to %s (took %.3fs)', out_name, duration)

            if job:
                job.meta['progress'] = 100
                job.meta['output_path'] = str(out_name.name)
                job.save_meta()

            return {'status':'success', 'output': str(out_name.name), 'duration_s': duration}
    except FileNotFoundError as e:
        logger.exception('File not found: %s', e)
        # Do not retry this - permanent error
        raise
    except OSError as e:
        # Could be a transient I/O error - raise TransientError to suggest a retry
        logger.exception('I/O error while processing image: %s', e)
        raise TransientError(str(e))
    except Exception as e:
        logger.exception('Unexpected error in resize_image: %s', e)
        # Reraise to let RQ mark the job failed (and retry if configured)
        raise
