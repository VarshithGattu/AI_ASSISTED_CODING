import logging, sys
from logging.handlers import RotatingFileHandler
from pathlib import Path
import re
import unicodedata
import uuid

def setup_logging(log_file=None, level=logging.INFO):
    """Configure root logger to log to console and optionally to a rotating file."""
    root = logging.getLogger()
    if root.handlers:
        return root  # already configured
    formatter = logging.Formatter('%(asctime)s %(levelname)-8s %(name)s: %(message)s')
    ch = logging.StreamHandler(sys.stdout)
    ch.setFormatter(formatter)
    root.setLevel(level)
    root.addHandler(ch)
    if log_file:
        fh = RotatingFileHandler(str(log_file), maxBytes=5_000_000, backupCount=3)
        fh.setFormatter(formatter)
        root.addHandler(fh)
    return root

_filename_strip_re = re.compile(r'[^A-Za-z0-9_.-]')

def secure_filename(filename: str) -> str:
    """Return a secure ASCII-only filename. Simplified implementation similar to Werkzeug's secure_filename."""
    if not filename:
        return uuid.uuid4().hex
    filename = unicodedata.normalize('NFKD', filename).encode('ascii', 'ignore').decode('ascii')
    filename = _filename_strip_re.sub('', filename).strip('._-')
    if not filename:
        return uuid.uuid4().hex
    return filename

def human_readable_size(num_bytes: int) -> str:
    for unit in ['B','KB','MB','GB','TB']:
        if num_bytes < 1024.0:
            return f"{num_bytes:3.1f}{unit}"
        num_bytes /= 1024.0
    return f"{num_bytes:.1f}PB"
