"""Worker process launcher. Start this in a separate terminal to begin processing jobs."""
import os, time, logging
from rq import Worker, Queue, Connection
import redis
from utils import setup_logging
from config import REDIS_URL, QUEUE_NAME, LOG_FILE

setup_logging(log_file=LOG_FILE)
logger = logging.getLogger(__name__)

listen = [QUEUE_NAME]
redis_conn = redis.from_url(REDIS_URL)

if __name__ == '__main__':
    with Connection(redis_conn):
        worker = Worker(list(map(Queue, listen)))
        logger.info('Worker starting, listening to queues: %s', listen)
        try:
            worker.work(with_scheduler=True)
        except Exception as e:
            logger.exception('Worker terminated unexpectedly: %s', e)
